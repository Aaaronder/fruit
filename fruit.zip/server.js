const port = 3000;
const express = require('express');
const app = express();
app.use(express.json());
let fruits = [
];

app.get('/fruit', (req, res) => {
    res.header('Content-Type', 'application/json');
    res.status(200);
    res.json(fruits);
})

app.post('/fruit', (req, res) => {
    console.log(req.body)
    let newFruit = req.body;
    fruits.push(newFruit);
    res.send(`Új gyümölcs hozzáadva: id: ${newFruit.id}, name: ${newFruit.fruit}, size: ${newFruit.size}, color: ${newFruit.color}`)
})

app.put('/fruit/:id', (req, res) => {
    console.log(req.params.id);
    let id = req.params.id;
    let newFruit = req.body;
    fruits[id]= newFruit;
    res.send(JSON.stringify(req.body));
});

app.delete('/fruit/:id', (req, res) => {
    let id = req.params.id;
    fruits.splice(id, 1);
    res.send(JSON.stringify(req.body));
    /*res.send(`V: ${fruit[id].fruit}, kor ${fruit[id].size} foglalkozás ${fruit[id].color}`);*/
})

app.listen(port, () => {
    console.log(`Express szerver indítva. Port: ${port}`);
});